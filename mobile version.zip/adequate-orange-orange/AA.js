import { Text, SafeAreaView, StyleSheet } from 'react-native';

// You can import supported modules from npm
import { Card } from 'react-native-paper';

// or any files within the Snack
import AssetExample from './components/AssetExample';

export default function App() {
      SameSite="None; Secure";
      type="module";
      src="https://cdn.landbot.io/landbot-3/landbot-3.0.0.mjs";
        var myLandbot = new Landbot.Fullpage({
          configUrl: 'https://storage.googleapis.com/landbot.online/v3/H-2883048-XX6B5IWDZKV69MYZ/index.json',
        });
}